// app/api/todos/route.ts

import { NextResponse } from 'next/server';

export interface Todo {
  id: number;
  title: string;
  completed: boolean;
}

// In-memory storage for todos
let todos: Todo[] = [
  { id: 1, title: 'Learn Next.js', completed: false },
  { id: 2, title: 'Build Todo API', completed: true },
];

// GET handler: returns the todo list
export async function GET() {
  return NextResponse.json(todos);
}

// POST handler: adds a new todo
export async function POST(request: Request) {
  try {
    const data = await request.json();
    if (!data.title || typeof data.title !== 'string') {
      return NextResponse.json({ error: 'Title is required and must be a string' }, { status: 400 });
    }

    const newTodo: Todo = {
      id: todos.length ? todos[todos.length - 1].id + 1 : 1,
      title: data.title,
      completed: false,
    };
    todos.push(newTodo);

    return NextResponse.json(newTodo, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: 'Invalid JSON' }, { status: 400 });
  }
}
