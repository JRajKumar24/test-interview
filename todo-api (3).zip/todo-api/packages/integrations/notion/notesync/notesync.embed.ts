// packages/integrations/notion/notesync/notesync.embed.ts
import * as React from 'react';

interface NoteSyncEmbedProps {
  noteId: string;
  className?: string;
  style?: React.CSSProperties;
}

/**
 * Mock component to embed a NoteSync note in the UI
 * 
 * @param noteId - The ID of the note to display
 * @param className - Optional CSS class for styling
 * @param style - Optional inline styles
 * @returns React component displaying mock note content
 */
export const NoteSyncEmbed: React.FC<NoteSyncEmbedProps> = ({ 
  noteId, 
  className = '', 
  style = {} 
}) => {
  // Mock note data that would normally come from an API
  const mockNote = {
    id: noteId,
    title: `Note: ${noteId}`,
    content: `This is a mock embed of note ${noteId}. In a real implementation, this would show actual note content fetched from the NoteSync API.`,
    lastUpdated: new Date().toISOString(),
  };

  return (
    <div 
      className={`notesync-embed ${className}`}
      style={{
        border: '1px solid #ddd',
        borderRadius: '8px',
        padding: '16px',
        margin: '8px 0',
        ...style,
      }}
    >
      <h4 style={{ marginTop: 0 }}>{mockNote.title}</h4>
      <p>{mockNote.content}</p>
      <small>Last updated: {new Date(mockNote.lastUpdated).toLocaleString()}</small>
    </div>
  );
};