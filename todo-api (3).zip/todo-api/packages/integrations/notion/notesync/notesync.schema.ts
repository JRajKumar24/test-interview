// packages/integrations/notion/notesync/notesync.schema.ts
import { z } from 'zod';

/**
 * Schema for validating input parameters for NoteSync operations
 */
export const NoteSyncSchema = {
  listNotes: z.object({
    // Maximum number of results to return
    maxResults: z.number().int().positive().optional().default(10),
    // Search query to filter notes
    query: z.string().optional(),
    // Optional filter for archived notes
    includeArchived: z.boolean().optional().default(false),
  }),
};

/**
 * Type definitions derived from the schemas for TypeScript support
 */
export type ListNotesInput = z.infer<typeof NoteSyncSchema.listNotes>;