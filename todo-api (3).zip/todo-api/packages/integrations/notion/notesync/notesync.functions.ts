// packages/integrations/notion/notesync/notesync.functions.ts
import { NoteSyncSchema, ListNotesInput } from './notesync.schema';

// Mock data for our NoteSync notes
const MOCK_NOTES = [
  {
    id: 'note-1',
    title: 'Meeting Notes',
    content: 'Discussed project timeline and deliverables',
    createdAt: new Date('2023-05-15'),
    isArchived: false,
  },
  {
    id: 'note-2',
    title: 'Ideas Board',
    content: 'Potential features for the next release',
    createdAt: new Date('2023-05-10'),
    isArchived: true,
  },
  {
    id: 'note-3',
    title: 'Technical Research',
    content: 'Findings about the new framework',
    createdAt: new Date('2023-05-20'),
    isArchived: false,
  },
];

/**
 * Mock function to list notes from NoteSync
 * @param input Filtering parameters
 * @returns Promise with list of notes
 */
export async function listNotes(input: ListNotesInput) {
  // Filter notes based on input parameters
  let notes = MOCK_NOTES.filter(note => {
    // Filter by query if provided
    const matchesQuery = !input.query || 
      note.title.toLowerCase().includes(input.query.toLowerCase()) || 
      note.content.toLowerCase().includes(input.query.toLowerCase());
    
    // Filter by archived status if needed
    const matchesArchiveStatus = input.includeArchived || !note.isArchived;
    
    return matchesQuery && matchesArchiveStatus;
  });

  // Apply maxResults limit
  if (input.maxResults) {
    notes = notes.slice(0, input.maxResults);
  }

  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 300));

  return {
    success: true,
    data: notes,
    metadata: {
      totalNotes: MOCK_NOTES.length,
      returnedNotes: notes.length,
    },
  };
}