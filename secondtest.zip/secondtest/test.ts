import { listNotes } from './packages/integrations/notion/notesync/notesync.functions';

listNotes({ maxResults: 2 }).then(notes => console.log(notes));