import { z } from 'zod';

export const listNotesSchema = z.object({
  maxResults: z.number().min(1).max(100).default(10),
  query: z.string().optional(),
});

export type ListNotesParams = z.infer<typeof listNotesSchema>;