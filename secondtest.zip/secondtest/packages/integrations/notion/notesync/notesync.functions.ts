import { listNotesSchema } from './notesync.schema';
import { z } from 'zod';

const mockNotes = [
  { id: '1', title: 'Shopping List', content: 'Milk, Eggs, Bread' },
  { id: '2', title: 'Meeting Notes', content: 'Discuss project timeline' },
  { id: '3', title: 'Ideas', content: 'Build a new feature' },
];

export async function listNotes(params: z.infer<typeof listNotesSchema>) {
  const filteredNotes = params.query
    ? mockNotes.filter(note => 
        note.title.includes(params.query!) || 
        note.content.includes(params.query!)
      )
    : mockNotes;

  return filteredNotes.slice(0, params.maxResults);
}