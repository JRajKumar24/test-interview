import { listNotes } from './notesync.functions';

export async function displayNotes(maxResults = 5) {
  const notes = await listNotes({ maxResults });
  notes.forEach(note => {
    console.log(`📝 ${note.title}`);
    console.log(`   ${note.content}`);
    console.log('---');
  });
}