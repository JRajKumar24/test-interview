import { useState } from 'react';

export default function Home() {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<{ from: 'user' | 'ai'; text: string }[]>([]);
  const [loading, setLoading] = useState(false);

  const sendMessage = async () => {
    if (!input.trim()) return;

    setMessages((prev) => [...prev, { from: 'user', text: input }]);
    setLoading(true);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: input }),
      });

      const data = await res.json();
      setMessages((prev) => [...prev, { from: 'ai', text: data.reply }]);
    } catch {
      setMessages((prev) => [...prev, { from: 'ai', text: 'Error: Could not get response' }]);
    }

    setInput('');
    setLoading(false);
  };

  return (
    <div style={{ maxWidth: 500, margin: '50px auto', padding: 20 }}>
      <h1>🤖 AI Chat</h1>
      <div style={{ border: '1px solid #ccc', padding: 10, minHeight: 200, marginBottom: 10 }}>
        {messages.map((m, i) => (
          <div key={i} style={{ textAlign: m.from === 'user' ? 'right' : 'left' }}>
            <b>{m.from === 'user' ? 'You' : 'AI'}:</b> {m.text}
          </div>
        ))}
        {loading && <div><i>AI is typing...</i></div>}
      </div>
      <input
        type="text"
        placeholder="Ask something..."
        value={input}
        onChange={(e) => setInput(e.target.value)}
        onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
        style={{ width: '100%', padding: 10 }}
      />
      <button onClick={sendMessage} style={{ width: '100%', marginTop: 10 }}>
        Send
      </button>
    </div>
  );
}
